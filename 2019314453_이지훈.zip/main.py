from typing import Union
from fastapi import FastAPI, Request, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import sqlite3
from datetime import datetime

from typing import List


app = FastAPI()

app.mount("/static",StaticFiles(directory="static",html = True), name="static")
templates = Jinja2Templates(directory="templates")

class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)

manager = ConnectionManager()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await manager.broadcast(data)
    except WebSocketDisconnect:
        manager.disconnect(websocket)



# 데이터 모델 정의
class Message(BaseModel):
    user_id: str
    content: str
    timestamp: datetime
    message_type: str  # 'user' 또는 'opp'


# SQLite 데이터베이스 연결 및 테이블 생성
def get_db_connection():
    conn = sqlite3.connect('chat.db')
    conn.execute('''CREATE TABLE IF NOT EXISTS messages
             (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, content TEXT, timestamp TEXT, message_type TEXT)''')

    return conn

@app.get("/")
def read_root(req: Request):
    return templates.TemplateResponse("index.html",{"request": req})
# 메시지 저장 API


@app.post("/messages/")
async def create_message(message: Message):
    conn = get_db_connection()
    cursor = conn.cursor()
    # message_type 필드를 INSERT 쿼리에 추가
    cursor.execute("INSERT INTO messages (user_id, content, timestamp, message_type) VALUES (?, ?, ?, ?)",
                   (message.user_id, message.content, str(message.timestamp), message.message_type))
    conn.commit()
    conn.close()
    return {"message": "Message saved successfully"}


# 특정 사용자의 메시지 검색 API
@app.get("/messages/{user_id}/{message_type}")
async def read_messages(user_id: str, message_type: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM messages WHERE user_id = ? AND message_type = ?", (user_id, message_type))
    messages = cursor.fetchall()
    conn.close()
    if not messages:
        raise HTTPException(status_code=404, detail="Messages not found")
    return {"messages": messages}


# 모든 메시지 검색 API
@app.get("/messages/")
async def read_all_messages():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM messages")
    messages = cursor.fetchall()
    conn.close()
    return {"messages": messages}
